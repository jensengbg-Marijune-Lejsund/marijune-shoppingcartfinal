const express = require('express')
const lowdb = require('lowdb')
const FileSync = require('lowdb/adapters/FileSync')     //all the server junk
const adapter = new FileSync('database.json')
const database = new lowdb(adapter)
const app = express()
const port = 8080

app.use(express.static('public'));

app.use((request, response, next) => {                  //fixes the error for allowance
    response.setHeader('Access-Control-Allow-Origin', 'http://192.168.1.237:5500');
    next();
  });

app.get('/api/products', (request, response) => {       //gets all products
    const data = database.get('products').value();
    response.send(data);
});


app.get('/api/cart', (request, response) => {           //gets the cart
    const data = database.get('cart').value();
    response.send(data);
});


app.post('/api/cart', (request, response) => {
    const queryID = Number(request.query.id);
    const product = database.get('products').find({id: queryID}).value();
    const productInCart = database.get('cart').find({id: queryID}).value();
    console.log(productInCart);
    if (product === undefined) {                                                //if not available, send error message
        response.json({success: false, message: 'Product not in database.'});
    } else {                                                                    //else add to cart
        if (productInCart !== undefined) {                                      //checks if already in cart, then not allowed
            response.json({success: false, message: 'Product already in cart.'}); 
        } else {                                                                //if not, then allow to add
            database.get('cart').push(product).write();
            response.json({success: true}); 
        }
    }
});

app.delete('/api/cart', (request, response) => {
    const queryID = Number(request.query.id);
    const product = database.get('cart').find({id: queryID}).value();
    if (product === undefined) {                                                //if not available, send error message
        response.json({success: false, message: "Product not in cart."});
    } else {
        database.get('cart').remove({id: queryID}).write()                      //if actually in cart, remove it
        response.json({message: "Product deleted."})
    }
    console.log(product);
});

app.listen(port)