const cartUrl = 'http://localhost:8080/api/cart'
const productsElem = document.querySelector('.products-container')
let cart = [];


async function getCart() {
    const response = await fetch(cartUrl);
    cart = await response.json();
    console.log(cart);
    numberInCart.innerHTML = cart.length;
    displayDataInCart();
    }
getCart();

function displayDataInCart(){
    productsElem.innerHTML = '';
    
    if (cart.length > 0) {
        for (let i = 0; i < cart.length; i++) {
            let node = document.createElement('li');
            let images = document.createElement('img');
            let deleteButton = document.createElement('button');
            node.innerHTML = cart[i].Name + ' - ' + cart[i].Price;
            const imagesUrl = 'http://localhost:8080' + cart[i].image
            images.setAttribute('src', imagesUrl);
            deleteButton.setAttribute('data-code', cart[i].id)
            deleteButton.innerHTML = 'Delete';
            node.append(deleteButton);
            productsElem.append(node); 
            node.appendChild(images)
            deleteButton.addEventListener('click', (event) => {
                const code = event.target.getAttribute('data-code');
            deleteFromCart(code);
            })
            }
            } else {
            let node = document.createElement('li');
            node.innerHTML = 'Cart Empty.';
            productsElem.append(node);
        }
    }


//function deleteFromCart({})


async function deleteFromCart (node){
    const newCartUrl = cartUrl + '?id=' + node;
    
    console.log(newCartUrl);
    
    const response = await fetch(newCartUrl, {method: 'DELETE'});
    const answer = await response.json();
    console.log(answer);
    
    displayDataInCart();
    getCart();
}


