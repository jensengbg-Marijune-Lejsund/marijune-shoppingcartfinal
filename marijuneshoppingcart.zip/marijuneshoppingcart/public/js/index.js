


const baseUrl = 'http://localhost:8080/api/products/'
const cartUrl = 'http://localhost:8080/api/cart'

const productsElem = document.querySelector('.polishes')

const itemsInCart = document.querySelector('.products-container')

const numberInCart = document.querySelector('#numberInCart')


let data = [];
let cart = [];
    
async function getData() {
        const response = await fetch(baseUrl);
        data = await response.json();
        console.log(data);
        displayData(data);
    }

async function getCart() {
    const response = await fetch(cartUrl);
    cart = await response.json();
    console.log(cart);
    numberInCart.innerHTML = cart.length;
    }

function displayData(){
    productsElem.innerHTML = '';
    
    if (data.length > 0) {
        for (let i = 0; i < data.length; i++) {
            let node = document.createElement('li');
            let images = document.createElement('img');
            let addButton = document.createElement('button');
            node.innerHTML = data[i].Name + ' - ' + data[i].Price;
            const imagesUrl = 'http://localhost:8080' + data[i].image
            images.setAttribute('src', imagesUrl);
            addButton.setAttribute('data-code', data[i].id)
            addButton.innerHTML = 'Add to Cart';
            node.append(addButton);
            productsElem.append(node); 
            node.appendChild(images)
            addButton.addEventListener('click', (event) => {
                const code = event.target.getAttribute('data-code');
                addButton.innerHTML = 'In Cart';
                addToCart(code);
            })
            console.log(images);
            }
            } else {
            let node = document.createElement('li');
            node.innerHTML = 'No result';
            productsElem.append(node);
        }
    }

getData();

async function addToCart (code){
    const newCartUrl = cartUrl + '?id=' + code;
    
    console.log(newCartUrl);
    
    const response = await fetch(newCartUrl, {method: 'POST'});
    const answer = await response.json();
    console.log(answer);
    
    displayCart();
    console.log('look for ' + code);
    getCart();
}

function displayCart() {


    if (data.length > 0) {
        for (let i = 0; i < data.length; i++) {
    let node = document.createElement('li');
    node.innerHTML = data[i].Name + ' - ' + data[i].Price;
    //itemsInCart.append(node);
    }} else {
            let node = document.createElement('li');
            node.innerHTML = 'cart function';
            //itemsInCart.append(node);
        }
}

addToCart();











