async function getCart() {
    const response = await fetch(cartUrl);
    cart = await response.json();
    console.log(cart);
    numberInCart.innerHTML = cart.length;
    }
getCart();